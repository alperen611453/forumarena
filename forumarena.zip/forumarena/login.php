<?php
require 'db.php';

$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if ($username && $password) {
        $stmt = $conn->prepare("SELECT id, password FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                session_start();
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $username;
                header("Location: index.php");
                exit;
            } else {
                $message = "Şifre yanlış.";
            }
        } else {
            $message = "Kullanıcı bulunamadı.";
        }
    } else {
        $message = "Lütfen kullanıcı adı ve şifre girin.";
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Giriş Yap</title>
</head>
<body>
    <h2>Giriş Yap</h2>
    <form method="POST" action="login.php">
        <label>Kullanıcı Adı:</label><br>
        <input type="text" name="username" required><br><br>

        <label>Şifre:</label><br>
        <input type="password" name="password" required><br><br>

        <input type="submit" value="Giriş Yap">
    </form>
    <p><?php echo $message; ?></p>
</body>
</html>
$_SESSION['username'] = $username;

<?php
// Veritabanı bağlantısı
require 'db.php';

$message = '';

// Form gönderildi mi kontrol et
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);

    if (!empty($name)) {
        // SQL sorgusu - kategori ekle
        $stmt = $conn->prepare("INSERT INTO categories (name) VALUES (?)");
        $stmt->bind_param("s", $name);

        if ($stmt->execute()) {
            $message = "Kategori başarıyla eklendi!";
        } else {
            $message = "Hata: Kategori eklenemedi. Muhtemelen bu isim zaten var.";
        }

        $stmt->close();
    } else {
        $message = "Kategori adı boş olamaz.";
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8" />
    <title>Kategori Ekle</title>
</head>
<body>
    <h2>Kategori Ekle</h2>

    <?php if ($message): ?>
        <p><?php echo htmlspecialchars($message); ?></p>
    <?php endif; ?>

    <form action="add_category.php" method="POST">
        <label for="name">Kategori Adı:</label><br />
        <input type="text" id="name" name="name" required /><br /><br />
        <input type="submit" value="Ekle" />
    </form>

    <p><a href="index.php">Ana Sayfa</a></p>
</body>
</html>

<?php
session_start();
var_dump($_SESSION);
exit;
?>
<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['username'] !== 'admin') {
    echo "Bu sayfaya erişim yetkiniz yok.";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Admin Paneli</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Admin Panel</h1>
    <p><a href="index.php">Siteye Dön</a></p>

    <h2>Kategoriler</h2>
    <ul>
        <?php
        $result = $conn->query("SELECT * FROM categories");
        while ($cat = $result->fetch_assoc()) {
            echo "<li>" . htmlspecialchars($cat['name']) . " 
                  <a href='delete_category.php?id=" . $cat['id'] . "' onclick='return confirm(\"Silmek istediğine emin misin?\")'>Sil</a></li>";
        }
        ?>
    </ul>

    <h3>Yeni Kategori Ekle</h3>
    <form method="post" action="add_category.php">
        <input type="text" name="name" required placeholder="Kategori adı">
        <button type="submit">Ekle</button>
    </form>
</body>
</html>

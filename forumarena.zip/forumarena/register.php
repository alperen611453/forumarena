<?php
require 'db.php'; // Veritabanı bağlantısı

$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = password_hash($_POST['password'] ?? '', PASSWORD_DEFAULT);

    if ($username && $email && $password) {
        $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $email, $password);
        
        if ($stmt->execute()) {
            $message = "Kayıt başarılı! Giriş yapabilirsiniz.";
        } else {
            $message = "Hata oluştu: " . $stmt->error;
        }
    } else {
        $message = "Lütfen tüm alanları doldurun.";
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Kayıt Ol</title>
</head>
<body>
    <h2>Kayıt Ol</h2>
    <form method="POST" action="register.php">
        <label>Kullanıcı Adı:</label><br>
        <input type="text" name="username" required><br><br>

        <label>E-posta:</label><br>
        <input type="email" name="email" required><br><br>

        <label>Şifre:</label><br>
        <input type="password" name="password" required><br><br>

        <input type="submit" value="Kayıt Ol">
    </form>
    <p><?php echo $message; ?></p>
</body>
</html>

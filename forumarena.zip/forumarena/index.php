<?php session_start(); ?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>ForumArena</title>
    <style>
        /* Basit, temiz stil */
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 20px auto;
            padding: 0 15px;
            background-color: #f9f9f9;
            color: #333;
        }
        a {
            color: #007BFF;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        header {
            margin-bottom: 20px;
        }
        ul {
            list-style: none;
            padding-left: 0;
        }
        li {
            background: white;
            padding: 12px 15px;
            margin-bottom: 8px;
            border-radius: 5px;
            box-shadow: 0 0 4px rgba(0,0,0,0.1);
        }
        h1 {
            border-bottom: 2px solid #007BFF;
            padding-bottom: 5px;
        }
        .login-info {
            margin-bottom: 15px;
            font-size: 14px;
        }
    </style>
</head>
<body>
<header>
<?php
require 'db.php';

// Kullanıcı giriş kontrolü
if (isset($_SESSION['username'])) {
    echo "<p class='login-info'>Hoş geldin, <strong>" . htmlspecialchars($_SESSION['username']) . "</strong> | <a href='logout.php'>Çıkış Yap</a></p>";
} else {
    echo "<p class='login-info'><a href='login.php'>Giriş Yap</a> veya <a href='register.php'>Kayıt Ol</a></p>";
}

// Kategorileri çek
$sql = "SELECT * FROM categories";
$result = $conn->query($sql);

$categories = [];
while ($row = $result->fetch_assoc()) {
    $categories[] = $row;
}
?>
</header>

<main>
    <h1>Kategoriler</h1>
    <?php if (count($categories) > 0): ?>
        <ul>
            <?php foreach ($categories as $category): ?>
                <li>
                    <a href="threads.php?category_id=<?= $category['id'] ?>">
                        <?= htmlspecialchars($category['name']) ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p>Henüz kategori yok.</p>
    <?php endif; ?>
</main>

</body>
</html>
